#ifndef HELLOC_INT_RECT_HPP
#define HELLOC_INT_RECT_HPP

struct IntRect {
    int left;
    int top;
    int width;
    int height;
};

#endif //HELLOC_INT_RECT_HPP
