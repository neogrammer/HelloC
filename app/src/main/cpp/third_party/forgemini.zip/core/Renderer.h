//
// Created by jlhar on 11/27/2025.
//

#ifndef HELLOC_RENDERER_H
#define HELLOC_RENDERER_H


class Renderer {
public:
    Renderer(struct android_app* pApp) {}

    void render() {}
};


#endif //HELLOC_RENDERER_H
