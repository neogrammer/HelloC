#ifndef HELLOC_TILESET_HPP
#define HELLOC_TILESET_HPP

#include <vector>
#include <memory>
#include <string>
#include "../core/texture.hpp"
#include "../core/int_rect.hpp"
#include "tile.hpp"

class TileSet {
public:
    explicit TileSet(const char* tilesetPath);
    ~TileSet();

    void LoadContent();

    IntRect GetSourceRect(int tile_id) const;
    const Tile& GetTile(int tile_id) const;
    int GetTileCount() const;

    Texture* GetTexture() { return &mTilesheetTexture; }
    const std::string& GetTexturePath() const { return mTexturePath; }

private:
    // This function will need to be implemented using your project's asset loading mechanism.
    std::vector<char> ReadAssetFile(const std::string& path);
    void ParseTilesetFile(const std::string& path);

    std::string mTilesetPath;
    std::string mTexturePath;
    Texture mTilesheetTexture;

    std::vector<Tile> mTiles;

    int mSheetWidthInTiles;
    int mSheetHeightInTiles;
    static constexpr int TILE_IMAGE_WIDTH = 64;
    static constexpr int TILE_IMAGE_HEIGHT = 64;
};

#endif //HELLOC_TILESET_HPP