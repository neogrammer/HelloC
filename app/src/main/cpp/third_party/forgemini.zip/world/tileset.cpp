#include "tileset.hpp"
#include <sstream>
#include <stdexcept>
#include "asset_manager.hpp"

TileSet::TileSet(const char* tilesetPath)
    : mTilesetPath(tilesetPath), mSheetWidthInTiles(0), mSheetHeightInTiles(0) {
}

TileSet::~TileSet() = default;

void TileSet::LoadContent() {
    ParseTilesetFile(mTilesetPath);
    if (!mTexturePath.empty()) {
        mTilesheetTexture = AssetManager::GetInstance().LoadTexture(mTexturePath.c_str());
    }
}

void TileSet::ParseTilesetFile(const std::string& path) {
    auto fileBuffer = AssetManager::GetInstance().GetFileBuffer(path);
    if (!fileBuffer) {
        throw std::runtime_error("Could not open tileset file: " + path);
    }
    std::string fileContent(fileBuffer->begin(), fileBuffer->end());
    std::stringstream ss(fileContent);

    // Read texture path
    std::getline(ss, mTexturePath);

    // Read tilesheet dimensions
    ss >> mSheetWidthInTiles >> mSheetHeightInTiles;

    int totalTiles = mSheetWidthInTiles * mSheetHeightInTiles;
    mTiles.resize(totalTiles);

    for (int i = 0; i < totalTiles; ++i) {
        mTiles[i].tile_id = i;
    }

    // Helper lambda to read a block of flags
    auto readFlags = [&](auto member_ptr) {
        for (int i = 0; i < totalTiles; ++i) {
            int flag_value;
            ss >> flag_value;
            if (ss.fail()) {
                throw std::runtime_error("Failed to read flag for tile " + std::to_string(i));
            }
            mTiles[i].*member_ptr = (flag_value != 0);
        }
    };

    readFlags(&Tile::is_solid);
    readFlags(&Tile::is_interactible);
    readFlags(&Tile::is_warp);
    readFlags(&Tile::is_save);
    readFlags(&Tile::is_trigger);
    readFlags(&Tile::is_heal);
    readFlags(&Tile::is_damage);
    readFlags(&Tile::is_animated);
}

IntRect TileSet::GetSourceRect(int tile_id) const {
    if (tile_id < 0 || tile_id >= mTiles.size()) {
        return {0, 0, 0, 0}; // Invalid ID
    }
    int tileX = tile_id % mSheetWidthInTiles;
    int tileY = tile_id / mSheetWidthInTiles;
    return {tileX * TILE_IMAGE_WIDTH, tileY * TILE_IMAGE_HEIGHT, TILE_IMAGE_WIDTH, TILE_IMAGE_HEIGHT};
}

const Tile& TileSet::GetTile(int tile_id) const {
    if (tile_id < 0 || tile_id >= mTiles.size()) {
        throw std::out_of_range("Invalid tile_id");
    }
    return mTiles[tile_id];
}

int TileSet::GetTileCount() const {
    return mTiles.size();
}
